::: minipage
**Keywords:**\
smartphone; statistical analysis;\
social media usage;\
attention; stress level;\
productivity level
:::

::: minipage
:::

# Introduction

Smartphones have become an integral part of everyday life, particularly
among young people. Originally designed as communication tools, they
have evolved into multifunctional devices used for social interaction,
entertainment, information retrieval, and academic activities. Their
constant availability has raised growing interest in understanding how
smartphone use may influence cognitive functioning and everyday
productivity. Recent research indicates that smartphone use is not only
frequent but deeply embedded in students' academic routines. Mobile
devices are widely used during lectures, study sessions, and other
learning-related activities. At the same time, modern applications
increasingly incorporate attention-capturing design features such as
notifications, recommendation algorithms, and visual cues, which
encourage habitual checking behavior and compete for users' attentional
resources [@chen2021persuasive]. As a result, smartphone interaction
often occurs automatically rather than as a deliberate, goal-directed
activity.

A growing body of literature has examined the relationship between
smartphone use and academic and cognitive outcomes. Meta-analytic
evidence suggests that problematic smartphone use is associated with
lower academic performance, although the observed effects are generally
small [@amez2020smartphone; @paterna2024problematic]. One possible
explanation for these mixed findings is that smartphone use is often
treated as a single, uniform construct, despite substantial variation in
how, when, and why individuals engage with their devices.

Indeed, recent evidence suggests that context-dependent patterns of
smartphone use may be more strongly associated with negative outcomes
than overall screen time. Behaviors such as smartphone multitasking
during study sessions and checking messages while studying appear to
show stronger relationships with lower academic performance than general
usage measures [@sunday2021effects]. These findings indicate that
qualitative aspects of smartphone engagement may be more informative
than simple measures of daily screen time.

Experimental studies further suggest that smartphones may influence
cognitive functioning even in the absence of active use. It has been
shown that the mere presence of a smartphone can reduce attentional
control and increase cognitive distraction, suggesting that smartphones
may impose cognitive costs through attentional capture mechanisms
[@schwaiger2022impact]. Such findings highlight the importance of
examining attention as a potential mechanism linking smartphone-related
behavior to broader behavioral outcomes.

Despite accumulating evidence, several gaps remain in the literature.
Most studies focus either on general usage metrics or academic
performance outcomes, while less attention has been given to specific
behavioral usage patterns and their relationship with cognitive
mechanisms. In addition, it remains unclear whether context-specific
forms of smartphone use explain variability in outcomes more effectively
than global indicators such as screen time.

The present study does not aim to determine whether smartphones are
universally harmful. Instead, it investigates whether specific patterns
of smartphone use---including daily screen time, phone use during
studying, morning phone checking habits, and perceived difficulty
disengaging from the device---are associated with self-reported
attention and productivity among students. Furthermore, the study
examines whether attention mediates the relationship between smartphone
use patterns and productivity, and whether distinct behavioral profiles
of smartphone users can be identified.

The study addresses the following research questions:

**RQ1:** Are global measures (screen time) stronger predictors of
attention and productivity than context-dependent measures (phone use
during studying, morning phone checking)?

**RQ2:** Does attention mediate the relationship between smartphone use
patterns and productivity?

**RQ3:** Can distinct behavioral profiles of smartphone users be
identified that differ in attention and productivity?

# Related Works

## Smartphone usage and academic performance

Empirical research on the relationship between smartphone use and
academic outcomes has accumulated a substantial body of evidence;
however, findings remain mixed. Meta-analytic studies provide the most
comprehensive overview. For example, a meta-analysis of 29 studies
including approximately 49,000 students reported a small but
statistically significant negative association between problematic
smartphone use and academic performance ($r = −0.110$, $p < .001$).
Notably, this effect appears to be more pronounced in primary and
secondary school students, suggesting that age may be an important
moderating factor [@paterna2024problematic].

These findings are consistent with an earlier systematic review by Amez
and Baert [@amez2020smartphone], which reported that 18 out of 23
studies (78.3%) found a negative association between smartphone use and
academic performance. However, the authors also highlighted an important
methodological limitation: studies relying on self-reported GPA were
more likely to report null findings compared to those using objective
academic records.This suggests that measurement approaches for both
independent (smartphone use) and dependent (academic performance)
variables may systematically influence observed results.

Further nuance is provided by Sunday et al. [@sunday2021effects], who
meta-analyzed 44 studies and demonstrated that not all types of
smartphone use are equally detrimental. The strongest negative
associations were observed for multitasking with smartphones during
academic tasks ($r = -0.16$) and texting during class ($r = -0.13$),
whereas general screen time showed a weaker association ($r = -0.10$).
These findings suggest that how and when smartphones are used may be
more important than overall usage duration.

## Attention and cognitive impact

While Section 2.1 focuses on academic outcomes as behavioral endpoints,
a logical next step is to examine the cognitive mechanisms through which
smartphone use may exert its effects. Attention plays a central role in
this process. Experimental and behavioral evidence suggests that
smartphone use may influence attentional control. However, findings are
not fully consistent. Hartanto et al. [@hartanto2021problematic],
comparing screen time ($\beta = -0.07$, $p = .381$) and checking
frequency ($\beta = 0.03$, $p = .730$), did not find significant
associations with inhibitory control.These inconsistencies may be
explained by methodological differences: experimental studies often
capture short-term distraction effects, whereas observational data
reflect habitual usage patterns that may be moderated by individual
differences in self-regulation.

At the same time, laboratory studies indicate that cognitive effects of
smartphones may occur even in the absence of active use. Schwaiger and
Tahir [@schwaiger2022impact] found that participants performed
significantly better on an inhibitory control task (Stroop test) when
their smartphones were placed in another room compared to conditions
where the device was on the desk or in a pocket ($F(3,134) = 3.128$,
$p < .05$).This "mere presence" effect suggests that cognitive costs may
arise not only from direct interaction with smartphones but also from
attentional allocation toward the device.

Further evidence highlights habitual and context-dependent mechanisms of
distraction. Oulasvirta et al. [@oulasvirta2011habits] demonstrated that
smartphone checking behavior often occurs during low cognitive load
situations, such as waiting, boredom, or passive engagement (e.g.,
lectures), forming habitual interruption patterns that disrupt sustained
attention.

These effects may be reinforced by design features of digital
environments. Chen et al.[@chen2021persuasive] showed that persuasive
design elements such as notifications, visual cues, and algorithmic
recommendations encourage automatic checking behavior every 15-20
minutes, thereby fragmenting attention and reinforcing habitual
engagement cycles. At a broader cognitive level, Busch and
McCarthy[@busch2021antecedents], in a systematic review, reported that
problematic smartphone use is associated with inattentional blindness
and reduced situational awareness, indicating more general disruptions
in attentional allocation and stability. Finally, Almourad et
al.[@almourad2020defining], in an analysis of 47 definitions of digital
addiction, identified a cluster of attention-related
symptoms---including loss of control, intrusive thoughts about digital
content, distorted time perception, and compulsive checking---as core
diagnostic features, further emphasizing the central role of attentional
disruption in smartphone-related behaviors.

## Productivity and behavioral outcomes

If attention is considered a key cognitive mechanism through which
smartphone use affects behavior, then productivity and procrastination
represent key downstream outcomes reflecting task execution and
self-regulation. Procrastination is traditionally conceptualized as a
failure of self-regulation. Steel [@steel2007nature] defines
procrastination as the irrational delay of intended tasks despite
expecting negative consequences, emphasizing deficits in self-regulatory
control as a central mechanism. However, procrastination can also be
understood as an emotion regulation strategy, particularly in response
to tasks perceived as stressful, cognitively demanding, or aversive.
Under such conditions, individuals may avoid task engagement to reduce
negative affect and redirect attention toward more immediately rewarding
and less demanding stimuli, including smartphone use.

Empirical evidence supports this perspective. Esan et al.
[@esan2026impact] found that problematic smartphone use is associated
with lower academic performance, particularly under multitasking
conditions.Their study reported that 51.6% of students occasionally lost
track of time while using smartphones, and 21.7% delayed academic tasks
due to phone use, reflecting direct manifestations of procrastination
and impaired self-regulation. Similarly, Chen et al.
[@chen2021persuasive] reported that 44% of participants perceived
smartphones as negatively affecting their academic or professional
performance.

At a broader level, Busch and McCarthy[@busch2021antecedents] concluded
in their systematic review that problematic smartphone use is
consistently associated with reduced productivity through
procrastination, impaired time management, and multitasking, all of
which undermine sustained goal-directed behavior. Taken together, these
findings suggest a cognitive-executive cascade in which attentional
disruption contributes to reduced cognitive control, ultimately
resulting in decreased self-regulation, increased procrastination, and
lower productivity.

## Research gap: contradictions and open questions

Despite growing evidence, the literature remains fragmented and
contradictory. Experimental studies such as Schwaiger and Tahir
[@schwaiger2022impact] demonstrate that even the mere presence of a
smartphone can impair inhibitory control. However, Hartanto et al.
[@hartanto2021problematic] found no significant relationship between
objectively measured screen time ($\beta = -0.07$, $p = .381$) or
checking frequency ($\beta = 0.03$, $p = .730$) and inhibitory control.
These divergent findings may reflect methodological differences:
experimental paradigms capture potential distraction effects, whereas
observational measures reflect actual usage patterns that are influenced
by individual differences in self-regulation.

Supporting this interpretation, Sarker et al. (2025) found that 69.7% of
students believe they overuse their smartphones, while only 20.2% report
using time-management applications, suggesting limited self-awareness
and discrepancies between perceived and actual usage.

Furthermore, construct definition plays an important role. For instance,
introducing a construct such as "pervasiveness"---defined as the
frequency of smartphone use across academic, sleep, and social
contexts---may better predict academic performance than subjective
addiction scales. This suggests that global indicators such as "screen
time" or "smartphone addiction" may be context-dependent and less
closely aligned with behavioral outcomes than specific usage patterns
[@gerosa2021smartphone].

Importantly, most studies examine cognitive and behavioral outcomes in
isolation. Research on attentional effects [@schwaiger2022impact],
[@hartanto2021problematic] rarely includes direct measures of
productivity, while studies on academic performance
[@amez2020smartphone], [@paterna2024problematic] often lack cognitive
variables such as attention. As a result, the potential mediating role
of attention - whether smartphone use affects productivity through
attentional disruption - remains largely underexplored.

Additionally, user populations are often treated as homogeneous. Studies
by Oulasvirta et al. [@oulasvirta2011habits] and Noë et al.
[@noe2019identifying] have highlighted meaningful differences between
types of smartphone interaction (e.g., passive scrolling vs. active
engagement), suggesting that aggregating all usage into a single
construct may obscure important behavioral variation. Finally, Busch and
McCarthy [@busch2021antecedents] note that existing models of
problematic smartphone use explain only 10-27% of variance in cognitive
and behavioral outcomes. This indicates substantial unexplained
variability, likely driven by individual usage patterns and contextual
factors that are not adequately captured in most studies.

## Hypotheses

The literature suggests that smartphone usage may be associated with
both cognitive performance and behavioral outcomes such as attention and
productivity. However, findings remain mixed, and recent studies
emphasize that not only the amount of smartphone use, but also usage
patterns and psychological dependence may play an important role. In
particular, factors such as habitual phone checking and perceived
discomfort when being without a smartphone may further explain
individual differences in attention and productivity outcomes among
young adults. Based on these findings, the following hypotheses are
proposed:

**H1:** Smartphone usage is negatively associated with attentional
performance.

**H2:** Attentional performance is positively associated with
productivity and negatively associated with procrastination.

**H3:** Attentional performance mediates the relationship between
smartphone usage and productivity-related outcomes.

# Methodology

## Participants

Participation in the study was voluntary and anonymous. The online
questionnaire was distributed through social media platforms and online
communities and targeted individuals aged 18-30. Both students and
non-students were eligible to participate.

A total of 109 responses were collected. After data cleaning, 15
responses were excluded due to incomplete questionnaires ($n = 8$) and
age outside the target range ($n = 7$). The majority of respondents were
students. In terms of gender distribution, the sample included both male
and female participants, with a slight predominance of female
respondents. Most participants were concentrated in the younger age
range (18-24 years), while a smaller proportion belonged to the 25-30
age group. Detailed sample characteristics are reported in Table 1.

::: {#tab:demographics}
  **Variable**                 ***M* (SD)**   **Frequency (%)**
  --------------------------- -------------- -------------------
  Age                          22.09 (2.46)  
  Sex                                        
  Male                                           42 (44.7%)
  Female                                         52 (55.3%)
  Education Level                            
  Bachelor's student                             57 (60.6%)
  Master's student                               19 (20.2%)
  Employed                                       18 (19.1%)
  Daily screen time (hours)    6.94 (4.10)   
  Sleep duration (hours)       6.85 (0.91)   

  : Demographics
:::

## Measurement Tools

The survey included self-reported measures of smartphone and social
media usage, attention, productivity, and lifestyle factors. Smartphone
usage was assessed using questions on average daily screen time and
frequency of phone use during study or work sessions.

Smartphone use was assessed using three indicators: average daily screen
time (1 = \"Less than 2 hours\" to 5 = \"More than 5 hours\"), frequency
of phone use during study or work sessions (1 = \"Never\" to 5 =
\"Always\"), and a binary indicator of whether participants checked
their phone within five minutes of waking (0 = \"No\", 1 = \"Yes\").

Attention and productivity were measured using self-report Likert-scale
items, ranging from 1 (\"Strongly disagree\") to 5 (\"Strongly agree\").
The attention composite was calculated as the mean of three items:
sustained concentration ability, loss of concentration due to smartphone
use (reverse-coded), and difficulty disengaging from the smartphone
during task performance (reverse-coded). The productivity composite was
calculated as the mean of two items: perceived productivity during study
or work sessions and procrastination (reverse-coded).

In the final sample, the attention composite demonstrated acceptable
internal consistency (Cronbach's $\alpha = .72$), while the productivity
composite showed moderate reliability (Cronbach's $\alpha = .68$).

## Data Preprocessing

The initial dataset included 109 responses. All data were exported to
.csv format and processed in Python using the pandas and numpy
libraries. During data cleaning, 15 responses were excluded: 8 due to
missing values and 7 due to age outside the inclusion criterion (18--30
years). The final analytical sample consisted of 94 participants.

Variables reflecting smartphone usage frequency were converted from
categorical responses into ordinal numerical scales ranging from 1 to 5.
The \"morning phone checking\" variable was coded as binary (1 = Yes, 0
= No).

Based on these recoded variables, composite indices for attention and
productivity were constructed as described above.

## Statistical Analysis

All statistical analyses were conducted using JASP (version 0.18) and
Python. Prior to inferential analyses, assumptions of normality,
linearity, homoscedasticity, and multicollinearity were assessed.

**Descriptive statistics**. Means (M), standard deviations (SD),
frequencies, and percentages were calculated for all study variables.
Correlation analysis. To test H1 ("Smartphone use is negatively
associated with attention") and H2 ("Attention is positively associated
with productivity and negatively associated with procrastination"),
Pearson correlation coefficients (r) were computed. A correlation matrix
was generated for all numerical variables. Statistical significance was
set at ($p < .05$).

**Multiple linear regression**. To address RQ1 ("Are global smartphone
use metrics stronger predictors than context-dependent metrics?"),
multiple linear regression analysis was conducted with productivity as
the dependent variable. Predictor variables included daily screen time,
phone use during study/work sessions, morning phone checking, attention,
and stress level. For the regression model, R², standardized regression
coefficients $\beta$, and $p$-values were reported.

**Mediation analysis**. To test H3 ("Attention mediates the relationship
between smartphone use and productivity"), mediation analysis was
conducted using bootstrapping (5,000 resamples) to estimate indirect
effects. Smartphone use served as the independent variable (X),
attention as the mediator (M), and productivity as the dependent
variable (Y). Mediation was considered significant if the 95% confidence
interval for the indirect effect did not include zero.

**Cluster analysis**. To identify behavioral user profiles (RQ3),
K-means clustering was applied. The optimal number of clusters was
determined using the elbow method, supplemented by silhouette and
Davies-Bouldin indices. Variables included in the clustering procedure
were daily screen time, phone use during study/work, morning phone
checking, and stress level. After cluster identification, group
differences in attention and productivity were examined using one-way
ANOVA.

# Results

## Descriptive statistics

Descriptive statistics for all key variables are presented in Table 2.
The mean daily screen time was 3.42 (SD = 0.90) on a 5-point scale,
corresponding to approximately 4--6 hours per day. Social media use (M =
2.78, SD = 0.87), sleep duration (M = 3.18, SD = 0.70), and phone use
during studying (M = 3.20, SD = 0.88) were at moderate levels. Morning
phone checking was reported by 85.1% of respondents. The average stress
level was 2.22 (SD = 1.13) on a scale from 0 to 5.

The composite attention score had a mean of 2.71 (SD = 0.72), with
acceptable internal consistency (Cronbach's $\alpha = .72$).
Productivity (M = 3.33, SD = 0.97) and procrastination (M = 2.09, SD =
1.27) were analyzed as single-item measures because the two-item
productivity scale demonstrated poor internal consistency (inter-item
$r = .091$).

::: {#tab:descriptives}
  **Variable**                         ***M***   ***SD***   **Min**   **Max**   **$\alpha$**
  ----------------------------------- --------- ---------- --------- --------- --------------
  Smartphone Usage                                                             
  Screen Time                           3.42       0.90        2         5     
  Social Media                          2.78       0.87        1         5     
  Usage During Study/Work               3.20       0.88        1         5     
  Morning Check                         0.85       0.36        0         1     
  Lifestyle Factors                                                            
  Sleep Duration                        3.18       0.70        2         5     
  Stress Level                          2.22       1.13        2         5     
  Cognitive and Behavioral Outcomes                                            
  Attention                             2.71       0.72      1.33      4.67         .72
  Productive                            3.33       0.97        1         5     
  Procrastination                       2.09       1.27        1         5     

  : Descriptive Statistics of Key Variables
:::

::: flushleft
*Note*. Smartphone usage, sleep duration, and stress level were measured
on 1--5 scales. Morning Check was coded as 0 = No, 1 = Yes. Attention is
a composite score (Cronbach's $\alpha = .72$). Productivity and
Procrastination are single‑item indicators.
:::

## Correlation analysis

Pearson correlation analysis was conducted to examine relationships
between the study variables (Table 3). The strongest positive
correlation was observed between attention and productivity
($r = 0.457$, $p < .001$). Moderate positive correlations were also
found between screen time and social media use ($r = 0.465$,
$p < .001$), stress and phone use during studying ($r = 0.357$,
$p < .001$), and stress and attention ($r = 0.298$, $p < .01$).

::: {#tab:correlation}
                      ST                SM                SU                MC                SL                AT                PR
  ---- ----------------- ----------------- ----------------- ----------------- ----------------- ----------------- -----------------
  ST     **1.000\*\*\***       0.465\*\*\*           0.221\*             0.161         0.333\*\*             0.014             0.006
  SM         0.465\*\*\*   **1.000\*\*\***       0.357\*\*\*           0.203\*         0.293\*\*         0.295\*\*           0.206\*
  SU             0.221\*       0.357\*\*\*   **1.000\*\*\***             0.097       0.357\*\*\*           0.204\*           0.245\*
  MC               0.161           0.203\*             0.097   **1.000\*\*\***             0.137           0.218\*             0.123
  SL           0.333\*\*         0.293\*\*       0.357\*\*\*             0.137   **1.000\*\*\***         0.298\*\*         0.323\*\*
  AT               0.014         0.295\*\*           0.204\*           0.218\*         0.298\*\*   **1.000\*\*\***       0.457\*\*\*
  PR               0.006           0.206\*           0.245\*             0.123         0.323\*\*       0.457\*\*\*   **1.000\*\*\***

  : Pearson's Correlation Matrix with Significance
:::

::: center
*Note*. ST = Screen Time, SM = Social Media, SU = Study Usage, MC =
Morning Check, SL = Stress Level, AT = Attention, PR = Productivity.\
$^*p < .05$, $^{**}p < .01$, $^{***}p < .001$.

![image](./attention_productivity_scatter.png){width="65%"}

[]{#fig:scatter label="fig:scatter"}
:::

To visualize the main relationship between attention and productivity, a
scatter plot with linear regression line was constructed (Figure 1). The
plot illustrates a positive association between the two variables,
indicating that higher attention scores were associated with higher
self-reported productivity.

## Hypothesis Testing

**H1** predicted a negative relationship between smartphone usage and
attention. This hypothesis was not supported. Total screen time was not
significantly associated with attention ($r = 0.014$, $p = .897$).
However, several specific smartphone usage behaviors showed weak but
statistically significant positive associations with attention,
including social media use ($r = 0.295$, $p = .004$), smartphone use
during study ($r = 0.204$, $p = .049$), and morning phone checking
($r = 0.218$, $p = .035$).

**H2** proposed that attention would be positively associated with
productivity and negatively associated with procrastination. This
hypothesis was partially supported. Attention was significantly
positively correlated with productivity ($r = 0.208$, $p = .044$),
consistent with the expected direction. However, attention was also
significantly positively associated with procrastination ($r = 0.440$,
$p < .001$), contrary to the hypothesis.

**H3** H3 proposed that attention mediates the relationship between
smartphone usage and productivity. This hypothesis was not supported.
The prerequisite relationships were not observed, as smartphone usage
showed no meaningful association with attention (c = 0.029; a = 0.011).
Although attention was significantly associated with productivity (b =
0.279), the indirect effect was small (ab = 0.004), and the 95%
bootstrap confidence interval included zero \[-0.054, 0.070\],
indicating no significant mediation effect.

## Cluster analysis

K-means clustering was conducted to identify behavioral user profiles.
The optimal number of clusters was determined using the elbow method,
silhouette coefficient, and Davies-Bouldin index. As shown in Table 4,
the silhouette coefficient reached its highest value at $k = 3$ (0.376),
while Davies-Bouldin index reached its lowest value (1.033). Based on
these metrics, a three-cluster solution was selected for further
analysis. Mean values for each cluster are presented in Table 5.

::: {#tab:cluster_metrics}
   Cluster ($k$)   Silhouette Score   Davies-Bouldin Index
  --------------- ------------------ ----------------------
         2              0.306                1.348
         3              0.376                1.033
         4              0.305                1.138
         5              0.308                0.956
         6              0.333                1.065

  : Comparison of Cluster Metrics
:::

Cluster 0 ($n = 14$) was characterized by moderate screen time (3.07),
moderate phone use during studying (3.00), no morning phone checking,
relatively low stress (1.86), and the lowest attention (2.33) and
productivity (2.46) scores among all clusters.

Cluster 1 ($n = 28$) demonstrated the highest levels of screen time
(4.29), phone use during studying (3.86), stress (3.36), attention
(2.91), and productivity (2.98). All participants in this cluster
reported checking their phones in the morning.

Cluster 2 ($n = 52$) the largest group, showed relatively low screen
time (3.04), the lowest phone use during studying (2.90), and the lowest
stress level (1.71). Similar to Cluster 1, all participants in this
group reported morning phone checking.

::: {#tab:cluster_profiles}
  Variable         Cluster 0 ($n=14$)   Cluster 1 ($n=28$)   Cluster 2 ($n=52$)
  --------------- -------------------- -------------------- --------------------
  Screen Time             3.07                 4.29                 3.04
  Study Usage             3.00                 3.86                 2.90
  Morning Check           0.00                 1.00                 1.00
  Stress                  1.86                 3.36                 1.71
  Attention               2.33                 2.91                 2.70
  Productivity            2.46                 2.98                 2.63

  : Cluster Profiles
:::

The majority of respondents (55.3%) belonged to Cluster 2, while Cluster
1 accounted for 29.8% and Cluster 0 represented the smallest group
(14.9%).

A one-way ANOVA was conducted to examine differences between clusters in
attention, productivity, and procrastination. Results are presented in
Table 6. No statistically significant differences were found between
clusters in attention, $F(2, 91) = 
3.08$, $p = .051$, although the result approached statistical
significance. Similarly, no significant differences were observed for
productivity, $F(2, 91) = 0.23$, $p = .794$.

For attention, no statistically significant differences were found
between clusters, $F(2, 
91) = 3.078$, $p = .051$. Similarly, no significant differences were
observed for productivity, $F(2, 91) = 0.231$, $p = .794$, indicating
that cluster membership did not meaningfully differentiate participants
in terms of attentional capacity or self-reported productivity.

In contrast, a significant effect of cluster membership was found for
procrastination, $F(2, 91) = 3.97$, $p = .022$, with a moderate effect
size ($\eta^2 = .080$). Post-hoc Tukey HSD comparisons indicated that
Cluster 1 ($M = 2.57$) reported significantly higher levels of
procrastination compared to Cluster 0 ($M = 1.50$, $p = .025$), while no
other pairwise differences were statistically significant.

::: {#tab:anova}
  Variable           Cluster 0   Cluster 1   Cluster 2   $F(2,91)$   $p$    $\eta^2$
  ----------------- ----------- ----------- ----------- ----------- ------ ----------
  Attention            2.33        2.91        2.70        3.08      .051     .063
  Productivity         2.46        2.98        2.63        0.23      .794     .005
  Procrastination      1.50        2.57        1.98        3.97      .022     .080

  : ANOVA and Post-hoc Tests
:::

These findings suggest that cognitive outcomes such as attention and
productivity remain relatively stable across behavioral profiles,
whereas differences emerge primarily in behavioral self-regulation,
particularly procrastination.

# Discussion

This study investigated the relationship between smartphone use,
attention, productivity, and procrastination, as well as potential
behavioral profiles of smartphone users among young adults. Overall, the
findings provide a nuanced picture in which smartphone use is not
uniformly associated with cognitive and behavioral outcome, and where
attention plays a more complex role than initially hypothesized.

## Smartphone use and attention

H1 proposed a negative association between smartphone use and attention.
This hypothesis was not supported by the results. Overall screen time
was not significantly related to attention, suggesting that general
smartphone exposure does not necessarily impair attention capacity in
this sample. However, specific usage usage patterns showed weak but
statistically significant positive associations with attention,
including social media use, phone use during studying, and morning phone
checking.

These findings suggest that the relationship between smartphone use and
attention may be more complex than a simple linear association with
total screen time. The absence of a negative relationship indicates that
overall smartphone exposure alone is not sufficient to explain
variations in attention in this sample.

## Attention, productivity, and procrastination

H2 proposed that attention would be positively associated with
productivity and negatively associated with procrastination. This
hypothesis was partially supported. Attention was positively associated
with productivity, consistent with expectations, indicating that higher
attentional capacity is related to better perceived task performance.

However, attention was also positively associated with procrastination,
which contradicts the initial hypothesis. Rather than indicating a
measurement error, this finding may reflect a more complex role of
attention in self-regulatory processes. Based on prior theoretical work
by Piers Steel [@steel2007nature], procrastination can be understood not
only as a failure of self-regulation but also as an emotion regulation
strategy. From this perspective, individuals with higher attentional
awareness may also experience greater task salience, cognitive load, or
performance pressure, which can increase avoidance behaviors despite
maintained cognitive engagement.

Thus, attention in this study appears to function as a dual-factor
construct, being associated with both adaptive (productivity) and
maladaptive (procrastination) outcomes.

## Mediation hypothesis

H3 proposed that attention would mediate the relationship between
smartphone use and productivity. This hypothesis was not supported.
Smartphone use was not significantly associated with either attention or
productivity, which prevented the establishment of a mediation pathway.
Although attention was positively associated with productivity, the
indirect effect of smartphone use on productivity via attention was not
statistically significant.

These results suggest that attention does not function as a mediating
mechanism between smartphone use and productivity in this sample.
Instead, productivity appears to be more directly related to attentional
capacity rather than to smartphone use patterns.

## Behavioral profiles

Cluster analysis identified three distinct behavioral profiles. However,
cluster membership did not significantly differentiate participants in
terms of attention or productivity. Both variables remained relatively
stable across clusters, with no statistically significant differences
observed, although attention showed a marginal effect.

In contrast, cluster membership was significantly associated with
procrastination. Participants in the high-use, high-stress cluster
reported significantly higher levels of procrastination compared to the
low-use cluster. No other pairwise differences were significant. This
suggests that behavioral differences between smartphone user profiles
are primarily reflected in self-regulatory outcomes rather than
cognitive outcomes.

## Limitations

Several limitations should be considered when interpreting the findings
of this study.

First, the cross-sectional design does not allow for causal inferences.
Although associations between smartphone use, attention, productivity,
and procrastination were identified, it is not possible to determine the
directionality of these relationships.

Second, the study relied primarily on self-report measures. This may
introduce response biases, such as social desirability or subjective
over- or underestimation of smartphone use and behavioral outcomes. In
particular, constructs such as attention, productivity, and
procrastination may be influenced by individual perception rather than
objective performance indicators.

Third, some variables were measured using brief or single-item scales.
While this approach allowed for efficient data collection, it may have
limited the reliability and precision of measurement, particularly for
productivity and certain behavioral indicators.

Fourth, the sample size within some clusters was relatively small,
especially Cluster 0 ($n = 14$). This may reduce statistical power for
detecting between-group differences and limits the generalizability of
cluster-specific findings.

Finally, the sample consisted of university students, which may limit
the generalizability of the results to other populations. Smartphone use
patterns and self regulatory behaviors may differ across age groups,
educational contexts, and cultural settings.

# Conclusion

Overall, the findings suggest that smartphone use does not exert a
uniform or directly negative influence on attention or productivity.
Instead, cognitive and behavioral outcomes appear to depend on more
specific patterns of use and individual differences in attentional
functioning.

Importantly, attention emerged as a central variable in the model, being
positively associated with both productivity and procrastination. This
pattern indicates that attention may not operate solely as a protective
cognitive resource but may also co-occur with increased task awareness
and psychological pressure that contribute to procrastination.

Taken together, the results support a more differentiated view of
smartphone-related behaviors, in which effects are not uniformly
detrimental but vary depending on behavioral context and individual
cognitive characteristics.

::: thebibliography
99

Amez, S., & Baert, S. (2020). Smartphone use and academic performance: A
literature review. *International Journal of Educational Research*, 103,
101618.

Esan, D. T., Olawade, D. B., Atule, I. F., Emetere, M., David-Olawade,
A. C., Ramos, C. G., & Esan, T. O. (2026). The impact of smartphone use
on learning effectiveness: A case study of college students.

Gerosa, T., Gui, M., & Büchi, M. (2021). Smartphone use and academic
performance: A pervasiveness approach beyond addiction.

Hartanto, A., Chua, Y. J., Quek, F. Y. X., Wong, J., Ooi, W. M., &
Majeed, N. M. (2021). Problematic smartphone usage, objective smartphone
engagement, and executive functions: A latent variable analysis.

Oulasvirta, A., Rattenbury, T., Ma, L., & Raita, E. (2011). Habits make
smartphone use more pervasive. In *Proceedings of the SIGCHI Conference
on Human Factors in Computing Systems (CHI)*.

Schwaiger, E., & Tahir, R. (2022). The impact of nomophobia and
smartphone presence on fluid intelligence and attention.
*Cyberpsychology: Journal of Psychosocial Research on Cyberspace*,
16(1), Article 5. <https://doi.org/10.5817/CP2022-1-5>

Sunday, O. J., Adesope, O. O., & Maarhuis, P. L. (2021). The effects of
smartphone addiction on learning: A meta-analysis.

Paterna, A., Alcaraz-Ibáñez, M., Aguilar-Parra, J. M., Salavera, C.,
Demetrovics, Z., & Griffiths, M. D. (2024). Problematic smartphone use
and academic achievement: A systematic review and meta-analysis.
*Journal of Behavioral Addictions*, 13(2), 313--326.
<https://doi.org/10.1556/2006.2024.00014>

Chen, X., Hedman, A., Distler, V., & Koenig, V. (2021). Do persuasive
designs make smartphones more addictive? A mixed-methods study on
Chinese university students. *arXiv preprint arXiv:2106.02604*.
<https://arxiv.org/abs/2106.02604>

Giunchiglia, F., Zeni, M., Gobbi, E., Bignotti, E., & Bison, I. (2020).
Mobile social media usage and academic performance. *arXiv preprint
arXiv:2004.01392*. <https://arxiv.org/abs/2004.01392>

Wu, R., Yu, C., Pan, X., Liu, Y., Zhang, N., Fu, Y., Wang, Y., Zheng,
Z., Chen, L., Jiang, Q., Xu, X., & Shi, Y. (2023). MindShift: Leveraging
large language models for mental-states-based problematic smartphone use
intervention. *arXiv preprint arXiv:2309.16639*.
<https://arxiv.org/abs/2309.16639>

Sarker, P., Dey, D., & Jannat, M.-E. (2025). A notification based nudge
for handling excessive smartphone use. *arXiv preprint
arXiv:2507.14702*. <https://arxiv.org/abs/2507.14702>

Almourad, M. B., McAlaney, J., Skinner, T., Pleva, M., & Ali, R. (2020).
Defining digital addiction: Key features from the literature.
*Cyberpsychology, Behavior, and Social Networking*.
<https://doi.org/10.1089/cyber.2019.0650>

Ding, X., Xu, J., Chen, G., & Xu, C. (2022). Beyond smartphone overuse:
Identifying addictive mobile apps. *arXiv preprint arXiv:2202.XXXX*.
<https://arxiv.org/abs/2202.XXXX>

Noë, B., Turner, L. D., Linden, D. E. J., Allen, S. M., Winkens, B., &
Whitaker, R. M. (2019). Identifying indicators of smartphone addiction
through user-app interaction. *Computers in Human Behavior*.
<https://doi.org/10.1016/j.chb.2019.03.XXX>

Busch, P. A., & McCarthy, S. (2021). Antecedents and consequences of
problematic smartphone use: A systematic literature review of an
emerging research area. *International Journal of Information
Management*. <https://doi.org/10.1016/j.ijinfomgt.2020.102308>

Rozgonjuk, D., Levine, J. C., Hall, B. J., & Elhai, J. D. (2021). The
association between problematic smartphone use, depression, and anxiety
symptom severity and objectively measured smartphone use over one week.
*Computers in Human Behavior*, 123, 106890.
<https://doi.org/10.1016/j.chb.2021.106890>

Fogg, B. J. (2003). *Persuasive technology: Using computers to change
what we think and do*. Morgan Kaufmann.

Giunchiglia, F., & Gobbi, E. (2020). Mobile social media usage and
academic performance. *arXiv preprint arXiv:2004.01392*.
<https://arxiv.org/abs/2004.01392>

Daleiden, B. K., Hartley, K., & Bendixen, L. D. (n.d.). A self-regulated
learning perspective on smartphone presence, usage, and multitasking
while studying. Unpublished manuscript.

Steel, P. (2007). The nature of procrastination: A meta-analytic and
theoretical review of quintessential self-regulatory failure.
*Psychological Bulletin*, 133(1), 65--94.
:::
